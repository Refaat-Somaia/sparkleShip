#import <Flutter/Flutter.h>

@interface WifiScanPlugin : NSObject <FlutterPlugin>
@end
