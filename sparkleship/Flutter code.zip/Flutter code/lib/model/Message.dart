class Message{
 late  int id;
 late String message;
 late String sender;
 late bool isSender;
 late String date;

}